// pages/detail/detail.js
Page({
    data: {
  index: 0,
  date: '2019-09-01',
  time_start: '08:00',
  time_end:'22:00'
},
  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  bindStartTimeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time_start: e.detail.value
    })
  },
  bindEndTimeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time_end: e.detail.value
    })
  }
});
 