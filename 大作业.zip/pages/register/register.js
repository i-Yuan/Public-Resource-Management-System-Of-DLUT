// pages/register/register.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number: null,
    phone: null,
    password: null,
    ensurepassword: null
  },

  goLogin: function () {
    wx.redirectTo({
      url: '../login/login',
    })
  },
  getNumber: function (e) {
    if (e.detail.value) {
      this.setData({
        number: e.detail.value
      })
    }
    console.log(this.data.number);
  },
  getPassword: function (e) {
    if (e.detail.value) {
      this.setData({
        password: e.detail.value
      })
    }
  },

  getPhone: function (e) {
    if (e.detail.value) {
      this.setData({
        phone: e.detail.value
      })
    }
  },
  getEnsurePassword: function (e) {
    if (e.detail.value) {
      this.setData({
        ensurepassword: e.detail.value
      })
      var currentFlag = 1
      var that = this;
      if (this.data.ensurepassword != this.data.password) {
        wx.showToast({
          title: '两次密码不一致',
          icon: "none"
        })
      }
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})